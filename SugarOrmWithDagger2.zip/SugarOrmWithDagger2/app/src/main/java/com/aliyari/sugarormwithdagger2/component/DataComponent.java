package com.aliyari.sugarormwithdagger2.component;

import com.aliyari.sugarormwithdagger2.model.Chronometer_model;
import com.aliyari.sugarormwithdagger2.model.Data;
import com.aliyari.sugarormwithdagger2.module.DataModule;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Created by Aliyari on 1/18/2018.
 */

@Singleton
@Component(modules = DataModule.class)
public interface DataComponent {

    Data provideData();
    Chronometer_model providChronometer();
}
