package com.aliyari.sugarormwithdagger2;

import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyari.sugarormwithdagger2.adapter.ChronometerAdapter;
import com.aliyari.sugarormwithdagger2.component.DaggerDataComponent;
import com.aliyari.sugarormwithdagger2.component.DataComponent;
import com.aliyari.sugarormwithdagger2.model.Chronometer_model;
import com.aliyari.sugarormwithdagger2.model.Data;
import com.aliyari.sugarormwithdagger2.module.DataModule;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Chronometer chronometer;
    TextView start, save;
    Handler handler = null;
    ImageView delete;
    RecyclerView recycler;
    //List<Chronometer_model> chronometer_list;
    ArrayList<Data> dataList = new ArrayList<>();
    Chronometer_model chronometerModel;

    DataComponent component = null;
    Data data = null;
    Chronometer_model inputChronData = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chronometer = (Chronometer) findViewById(R.id.chronometer);
        recycler = (RecyclerView) findViewById(R.id.recycler);
        start = (TextView) findViewById(R.id.btn_start);
        save = (TextView) findViewById(R.id.btn_save);
        delete=(ImageView) findViewById(R.id.img_delete);
        handler = new Handler();


        save.setOnClickListener(this);
        start.setOnClickListener(this);

///************
        component = DaggerDataComponent.builder().dataModule(new DataModule()).build();
        data = component.provideData();
        //  inputChronData=component.providChronometer();
        dataList.add(data);
        //   Toast.makeText(this, "" + data, Toast.LENGTH_SHORT).show();
        // chronometer_list = Chronometer_model.listAll(Chronometer_model.class);

        ChronometerAdapter adapter = new ChronometerAdapter(getApplicationContext(), dataList);
        recycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()
                , LinearLayoutManager.VERTICAL, false));
        recycler.setAdapter(adapter);
//

    }

    @Override
    public void onClick(View v) {
        if (v == start) {

            handler.post(new Runnable() {
                @Override
                public void run() {
                    chronometer.setBase(SystemClock.elapsedRealtime());
                    chronometer.start();
                }
            });

        }
        if (v == save) {
            getValue();
        }
        if (v==delete){
            Chronometer_model ch = new Chronometer_model();
            ch.delete();
        }
    }

    /*get curent date and time to write in db */
    private void getValue() {

        /*get time by format*/
        SimpleDateFormat df2 = new SimpleDateFormat(" hh:mm a ");
        Date getCurentdate = new Date();
        String time = df2.format(getCurentdate);


        Calendar calendar = java.util.Calendar.getInstance();

        int year = calendar.get(calendar.YEAR);
        int month = calendar.get(calendar.MONTH) + 1;
        int day = calendar.get(calendar.DAY_OF_MONTH);

        String chron_time = (chronometer.getText().toString());
        chronometer.setBase(SystemClock.elapsedRealtime());


        try {

            ///////********
//            chronometerModel = new Chronometer_model(year + "", month + "", day + "", time + "", chron_time);
//            chronometerModel.save();


            component = DaggerDataComponent.builder().dataModule(new DataModule()).build();
            // inputChronData = component.providChronometer();
            data = component.provideData();
            data.setYears(year + "");
            data.setMonth(month + "");
            data.setDay(day + "");
            data.setTime(time + "");
            data.setChronometer(chron_time + "");


        } catch (Exception e) {
            e.printStackTrace();
        }


        dataList.add(data);

        //Toast.makeText(this, ""+data, Toast.LENGTH_SHORT).show();

        ////*************
        // chronometer_list = Chronometer_model.listAll(Chronometer_model.class);
        ChronometerAdapter adapter = new ChronometerAdapter(getApplicationContext(), dataList);
        recycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()
                , LinearLayoutManager.VERTICAL, false));
        recycler.setAdapter(adapter);
    }


}

