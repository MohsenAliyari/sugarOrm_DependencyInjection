package com.aliyari.sugarormwithdagger2.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyari.sugarormwithdagger2.R;
import com.aliyari.sugarormwithdagger2.component.DaggerDataComponent;
import com.aliyari.sugarormwithdagger2.component.DataComponent;
import com.aliyari.sugarormwithdagger2.model.Chronometer_model;
import com.aliyari.sugarormwithdagger2.model.Data;
import com.aliyari.sugarormwithdagger2.module.DataModule;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Aliyari on 1/16/2018.
 */

public class ChronometerAdapter extends RecyclerView.Adapter<ChronometerAdapter.ViewHolder> {

    Context context;
    ArrayList<Data> list;

    public ChronometerAdapter(Context context, ArrayList<Data> arrayList) {

        this.context = context;
        this.list = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.chronom_row, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {


//            Chronometer_model choronometerList = list.get(position);
//            holder.year.setText(choronometerList.getYears());
//            holder.month.setText(choronometerList.getMonth());
//            holder.day.setText(choronometerList.getDay());
//            holder.time.setText(choronometerList.getTime());
//            holder.choron.setText(choronometerList.getChronometer());
//            holder.id.setText(choronometerList.getId() + "");

        DataComponent component = DaggerDataComponent.builder().dataModule(new DataModule()).build();
        Data data = component.provideData();
        Chronometer_model ch = component.providChronometer();


        data = list.get(position);
        holder.year.setText(data.getYears());
        holder.month.setText(data.getMonth());
        holder.day.setText(data.getDay());
        holder.time.setText(data.getTime());
        holder.choron.setText(data.getChronometer());
     //   holder.id.setText(data.getId());

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = Integer.parseInt(holder.id.getText().toString());

                Chronometer_model ch = Chronometer_model.findById(Chronometer_model.class, (long) id);
                ch.delete();

                removeItem(position);
            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView year, month, day, time, choron, id;
        ImageView delete;

        public ViewHolder(View itemView) {
            super(itemView);

            id = itemView.findViewById(R.id.txtv_id);
            year = itemView.findViewById(R.id.txtv_years);
            month = itemView.findViewById(R.id.txtv_month);
            day = itemView.findViewById(R.id.txtv_day);
            time = itemView.findViewById(R.id.txtv_time);
            choron = itemView.findViewById(R.id.txtv_Chronom);
            delete = itemView.findViewById(R.id.img_del);

        }

    }

    public void removeItem(int position) {
        list.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, list.size());
    }
}
